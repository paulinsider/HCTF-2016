<?php
include("config.php");
include("comm.php");

if (isset($_COOKIE['username']) && decrypt($_COOKIE['username'])!=="") {
  $_SESSION['username'] = decrypt($_COOKIE['username']);
  header("Location: /index.php");
  exit();
}

if (isset($_POST['username']) && isset($_POST['password'])) {

  if ($_POST['username']==='admin') {
    exit('Aklis is admin! �����ɶ��');
  }

  if ($_POST['username']==='' || $_POST['password']==='' || $_POST['gogogo']!=='��!')
  {
    exit("���¸��¸���.jpg");
  }

  if (strlen($_POST['username'])<= 5 || strlen($_POST['username'])>=20)
  {
    exit("�û����ַ��������5��С��20");
  }

  $mysqli = new mysqli(MYSQL_HOST, MYSQL_USER, MYSQL_PASSWORD, MYSQL_DATABASE);

  $username = $mysqli->escape_string($_POST['username']);
  $password = md5($_POST['password']);
  
  if ($mysqli->connect_errno) {
    exit("��".$mysqli->error);
  }
  
  if($result = $mysqli->query("select * from users where username='$username'")) {
    if ($result->num_rows) {
      $result->close();
      echo "�û��Ѵ���";
    } else {
      $query = "insert into users values (NULL, '$username', '$password', '');";
      if ($mysqli->query($query)===TRUE) {
        $mysqli->close();
        header("Location: /login.php");
      } else {
        exit("������ը�ˣ�".$mysqli->error);
      }
    }
  }


}
?>

<!DOCTYPE html>
<html>
  <head>
    <title>LIBRARY - HCTF</title>
    <meta charset="UTF-8">
    <link href="static/mui.min.css" rel="stylesheet" type="text/css" />
    <link href="static/style.css" rel="stylesheet" type="text/css" />
  </head>
  <body>
    <form action="" method="POST">
      <legend>Register</legend>
      <div class="mui-textfield">
        <input type="text" placeholder="Username" name="username">
      </div>
      <div class="mui-textfield">
        <input type="password" placeholder="Password" name="password">
      </div>
      <input type="submit" class="mui-btn mui-btn--raised" name="gogogo" value="��!" ></button>
    </form>
  </body>
</html>
