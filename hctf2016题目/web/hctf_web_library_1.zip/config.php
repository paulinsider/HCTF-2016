<?php
define('MYSQL_HOST', '127.0.0.1');
define('MYSQL_USER', 'aklis');
define('MYSQL_PASSWORD', 'aklis');
define('MYSQL_DATABASE', 'library');


error_reporting(0);
ini_set('display_errors', 'Off');
ini_set('allow_url_fopen', 'Off');
ini_set('session.cookie_httponly', 1);
session_start();
