<?php

$flag = "hctf{Lillie_is_comming}";