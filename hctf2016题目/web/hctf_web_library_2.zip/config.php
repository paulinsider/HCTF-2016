<?php
define('MYSQL_HOST', '192.168.0.2');
define('MYSQL_USER', 'root');
define('MYSQL_PASSWORD', 'aklis1s');
define('MYSQL_DATABASE', 'library');


error_reporting(1);
ini_set('display_errors', 'On');
ini_set('allow_url_fopen', 'Off');
ini_set('session.cookie_httponly', 1);
session_start();
