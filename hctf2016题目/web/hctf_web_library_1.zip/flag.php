<?php
$flag = "hctf{Serena_is_the_leading_role}";
